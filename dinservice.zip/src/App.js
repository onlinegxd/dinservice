import React from 'react';
import './css/App.module.css';
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import MainPage from './components/Pages/MainPage/MainPage';
import AboutPage from './components/Pages/AboutPage/AboutPage';
import { BrowserRouter, HashRouter, Route } from "react-router-dom";
import DeliveringPage from './components/Pages/DeliveringPage/DeliveringPage';
import CartPage from './components/Pages/CartPage/CartPage';
import AccountPage from './components/Pages/AccountPage/AccountPage';
import CataloguePage from './components/Pages/CataloguePage/CataloguePage';
import NewsPage from './components/Pages/NewsPage/NewsPage';
import Popup from './components/Popup/Popup';
import SearchPage from './components/Pages/SearchPage/SearchPage';
import OrderPage from './components/Pages/OrderPage/OrderPage';



if (localStorage.getItem("cart") === null) {
	localStorage.setItem("cart", JSON.stringify([]));
}


class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			cart: JSON.parse(localStorage.getItem("cart"))
		}
		this.handleCartChange = this.handleCartChange.bind(this);
	}

	handleCartChange(cart) {
		this.setState({ cart: cart });
		console.log(cart)
	}

	render() {
		return (
			<div className="App">
				<div className="modal fade" id="cartError" tabIndex="-1" role="dialog">
					<div className="modal-dialog">
						<div className="modal-content">
							<div className="modal-header alert-danger">
								<h5 className="modal-title">Данный товар уже есть в козине</h5>
								<button type="button" className="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
						</div>
					</div>
				</div>
				<HashRouter>
					<Header cart_length={this.state.cart.length} />
					<Route exact path='/' component={MainPage} />
					<Route path='/index.html' component={MainPage} />
					<Route path='/about' component={AboutPage} />
					<Route path='/delivering' component={DeliveringPage} />
					<Route path='/cart' render={() => <CartPage cart={this.state.cart} handleCartChange={this.handleCartChange} />} />
					<Route path='/account' render={() => <AccountPage cart={this.state.cart} handleCartChange={this.handleCartChange} />} />
					<Route path='/catalogue' component={CataloguePage} />
					<Route path='/news' component={NewsPage} />
					<Route path='/Search' component={SearchPage} />
					<Route path='/SearchCar' component={SearchPage} />
					<Route path='/SearchDetail' component={SearchPage} />
					<Route path='/SearchResult' component={SearchPage} />
					<Route path='/SearchQuick' component={SearchPage} />
					<Route path='/SearchOverall' render={() => <SearchPage cart={this.state.cart} handleCartChange={this.handleCartChange} />} />
					<Route path='/OrderPage' render={() => <OrderPage cart={this.state.cart} />} />
				</HashRouter>
				<Popup />
				<Footer />
			</div>
		);
	}
}

export default App;
