import * as React from "react";
import Nav from 'react-bootstrap/Nav';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import { BrowserRouter, HashRouter, Route } from "react-router-dom";
import Products from "./Products";
import Orders from "./Orders";
import Users from "./Users";
import Categories from "./Categories";
import Requests from "./Requests";

class EntranceForm extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			email: "",
			password: ""
		};
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
	}
	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'file' ? target.files[0] : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}
	handleSubmit(event) {
		event.preventDefault();
		if (this.state.email === "admin" && this.state.password === "7Rtp<+G3Y)E%shcu") {
			localStorage.setItem("dinas_admin", "pneQPLjxCHbJ#X+5XR)3,5CB!Zsy)j+J");
			alert("Вы успешно вошли в админ-панель");
			window.location.reload();
		}
		else {
			alert("При входе в админ-панель произошла ошибака. Попробуйте ещё раз");
		}
	}
	render() {
		if (localStorage.getItem("dinas_admin") === "pneQPLjxCHbJ#X+5XR)3,5CB!Zsy)j+J") {
			return (
				<div className="d-flex flex-column justify-content-center align-items-center mt-5">
					<h3>Вы уже вошли в админ-панель.</h3> <br />
					<Button variant="danger" type="button" onClick={() => { localStorage.removeItem("dinas_admin"); window.location.reload() }}>Выйти из админ панели</Button>
				</div>
			)
		}
		else {
			return (
				<div className="d-flex justify-content-center align-items-center mt-5">
					<Form onSubmit={this.handleSubmit}>
						<Form.Group controlId="formBasicEmail">
							<Form.Label>Email</Form.Label>
							<Form.Control type="text" required placeholder="Введите email администратора" name="email" onChange={this.handleInputChange} value={this.state.email} />
						</Form.Group>

						<Form.Group controlId="formBasicPassword">
							<Form.Label>Пароль</Form.Label>
							<Form.Control type="password" required placeholder="Введите пароль администратора" name="password" onChange={this.handleInputChange} value={this.state.password} />
						</Form.Group>
						<Button variant="primary" type="submit" className="w-100 text-center">Войти в админ панель</Button>
					</Form>
				</div>
			)
		}

	}
}

class AdminPanel extends React.Component {
	render() {
		const path = window.location.pathname;
		if (localStorage.getItem("dinas_admin") === "pneQPLjxCHbJ#X+5XR)3,5CB!Zsy)j+J") {
			return (
				<Container fluid >
					<Row>
						<Col xs={12}>
							<Nav justify variant="tabs" defaultActiveKey={path} className="">
								<Nav.Item>
									<Nav.Link href="#/admin/">Главная</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="#/admin/products">Товары</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="#/admin/requests">Заявки</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="#/admin/users">Клиенты </Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="#/admin/orders">Заказы</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="#/admin/categories">Категории</Nav.Link>
								</Nav.Item>
							</Nav>
						</Col>
						<Col xs={12}>
							<HashRouter>
								<Route path='/admin' exact render={() => <EntranceForm />} />
								<Route path='/admin/products' render={() => <Products />} />
								<Route path='/admin/users' render={() => <Users />} />
								<Route path='/admin/orders' render={() => <Orders />} />
								<Route path='/admin/categories' render={() => <Categories />} />
								<Route path='/admin/requests' render={() => <Requests />} />
							</HashRouter>
						</Col>
					</Row>
				</Container >
			)
		}
		else {
			return (
				<Container fluid >
					<Row>
						<Col xs={12}>
							<Nav justify variant="tabs" defaultActiveKey={path} className="">
								<Nav.Item>
									<Nav.Link href="/admin/" disabled>Главная</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="/admin/products" disabled>Товары</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="/admin/requests" disabled>Заявки</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="/admin/users" disabled>Клиенты </Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="/admin/orders" disabled>Заказы</Nav.Link>
								</Nav.Item>
								<Nav.Item>
									<Nav.Link href="/admin/categories" disabled>Категории</Nav.Link>
								</Nav.Item>
							</Nav>
						</Col>
						<Col xs={12}>
							<HashRouter>
								<Route path='/admin' exact render={() => <EntranceForm />} />
							</HashRouter>
						</Col>
					</Row>
				</Container >
			)
		}
	}
}

export default AdminPanel;