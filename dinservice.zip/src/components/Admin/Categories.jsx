import React from 'react';
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';


class AddCategory extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			categories: []
		};
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
	}

	async handleSubmit(event) {
		event.preventDefault();
		var data = new FormData();
		data.append("name", this.state.categoryName);
		//----------------------------
		let res = await fetch('http://dinas.kz/server/public/api/admin/add-category', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		console.log(res);
		if (res.status === "ok") {
			alert("Категория успешно добавлена");
			window.location.reload();
		}
		else {
			if (res.msg === "Invalid login or password!") {
				alert("Неверный логин или пароль. Попробуйте ещё раз.");
			}
		}
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'file' ? target.files[0] : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}

	render() {
		return (
			<Form onSubmit={this.handleSubmit}>
				<Form.Row>
					<Form.Group as={Col} controlId="formGridEmail">
						<Form.Label>Имя категории</Form.Label>
						<Form.Control type="text" placeholder="Введите имя" required onChange={this.handleInputChange} name="categoryName" />
					</Form.Group>
				</Form.Row>
				<Button variant="primary" type="submit">
					Добавить категорию
  				</Button>
			</Form>
		);
	}
}

class EditCategory extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			categories: []
		};
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
	}

	async handleSubmit(event) {
		event.preventDefault();
		function parseJSON(response) {
			return response.text().then(function (text) {
				return text ? JSON.parse(text) : {}
			})
		}
		var data = new FormData();
		data.append("id", this.state.categoryID);
		data.append("name", this.state.categoryName);
		//----------------------------
		let res = await fetch('http://dinas.kz/server/public/api/admin/update-category', {
			method: 'POST',
			body: data
		});
		res = await parseJSON(res);
		console.log(res);
		if (res.status === "ok") {
			alert("Категория успешно отрекдактирована");
			window.location.reload();
		}
		else {
			alert("При редактировании произошла ошибка.");
		}
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'file' ? target.files[0] : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}

	render() {
		return (
			<Form onSubmit={this.handleSubmit}>
				<Form.Row>
					<Form.Group as={Col} controlId="formGridEmail">
						<Form.Label>Имя категории</Form.Label>
						<Form.Control type="text" placeholder="Введите имя" required onChange={this.handleInputChange} name="categoryName" />
					</Form.Group>
					<Form.Group as={Col} controlId="formGridEmail">
						<Form.Label>ID категории</Form.Label>
						<Form.Control type="text" placeholder="Введите ID" required onChange={this.handleInputChange} name="categoryID" />
					</Form.Group>
				</Form.Row>

				<Button variant="primary" type="submit">
					Редактировать категорию
  				</Button>
			</Form>
		);
	}
}

class Categories extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			categories: []
		};
	}

	componentDidMount() {
		this.getCategories();
	}

	deleteCategory(id) {
		fetch(`http://dinas.kz/server/public/api/admin/delete-category/${id}`)
			.then(res => res.json())
			.then(
				(result) => {
					if (result.status === "ok") {
						alert("Категория с ID " + id + " была успешно удалёна.");
						window.location.reload();
					}
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					alert("Во время удаления произошла ошибка.");
				}
			)
	}

	getCategories(params) {
		fetch("http://dinas.kz/server/public/api/categories")
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						categories: result.categories
					});
					console.log(result.categories);
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	render() {
		const categories = this.state.categories;
		const tableItems = categories.map((item) =>
			<tr key={item.id}>
				<td>{item.id}</td>
				<td>{item.name}</td>
				<td>{item.code}</td>
				<td className="text-center">
					<Button className="mr-2" variant="danger" onClick={() => this.deleteCategory(item.id)}>Удалить</Button>
					<Button variant="info">Редактировать</Button>
				</td>
			</tr>);
		return (
			<Table striped bordered hover size="sm">
				<thead>
					<tr>
						<th>ID</th>
						<th>Имя</th>
						<th>Код</th>
						<th>Действия</th>
					</tr>
					<tr>
						<td colSpan="5">
							<AddCategory />
						</td>
					</tr>
					<tr>
						<td colSpan="5">
							<EditCategory />
						</td>
					</tr>
				</thead>
				<tbody>
					{tableItems}
				</tbody>
			</Table>
		);
	}
}

export default Categories;
