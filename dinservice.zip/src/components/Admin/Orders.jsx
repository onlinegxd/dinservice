import React from 'react';
import Table from 'react-bootstrap/Table';

class Orders extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			orders: []
		};

	}


	deleteOrder(id) {
		fetch(`http://dinas.kz/server/public/api/admin/orders/detele/${id}`)
			.then(res => res.json())
			.then(
				(result) => {
					if (result.status === "ok") {
						alert("Заказ с ID " + id + " был успешно удалён.");
						window.location.reload();
					}
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					alert("Во время удаления произошла ошибка.");
				}
			)
	}

	componentDidMount() {
		this.getOrders();
	}

	async getOrders(params) {

		let res = await fetch('http://dinas.kz/server/public/api/admin/orders', {
			method: 'GET'
		});
		res = await res.json();
		if (res.status === "ok") {
			this.setState({ orders: res.orders });
		}
	}

	render() {
		const orders = this.state.orders;
		const tableItems = orders.map((item) =>
			<tr key={item.id}>
				<td>{item.id}</td>
				<td>{item.city}</td>
				<td>{item.fio}</td>
				<td>{item.address}</td>
				<td>{item.email}</td>
				<td>{item.phone}</td>
				<td>
					<table>
						<thead>
							<tr>
								<td>ID</td>
								<td>Название</td>
								<td>Кол-во</td>
							</tr>
						</thead>
						<tbody>
							{JSON.parse(item.cart).map(item => <tr key={item.id}>
								<td>{item.id}</td>
								<td>{item.name}</td>
								<td>{item.count}</td>
							</tr>)}
						</tbody>
					</table>
				</td>
				<td className="text-center">
					<b>{item.total_price}</b>
				</td>
				<td className="text-center">
					<button type="button" className="btn btn-danger" onClick={() => this.deleteOrder(item.id)}>Удалить</button>
				</td>
			</tr>);
		return (
			<Table striped bordered hover size="sm">
				<thead>
					<tr>
						<th>ID</th>
						<th>Город</th>
						<th>Имя</th>
						<th>Адрес</th>
						<th>Email</th>
						<th>Телефон</th>
						<th>Корзина</th>
						<th>Сумма</th>
						<th>Действия</th>
					</tr>
				</thead>
				<tbody>
					{tableItems}
				</tbody>
			</Table>
		);
	}
}

export default Orders;
