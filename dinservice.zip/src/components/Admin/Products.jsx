import React from 'react';
import Table from 'react-bootstrap/Table';
// import Alert from 'react-bootstrap/Alert';
// import AddIcon from '@material-ui/icons/Add';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import { Link, Route } from 'react-router-dom';


class EditProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			product: [],
			categories: []
		};
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
	}
	async handleSubmit(event) {
		event.preventDefault();
		var data = new FormData();
		data.append("id", this.state.id);
		data.append("count", this.state.count);
		data.append("title", this.state.title);
		data.append("description", this.state.description);
		data.append("price", this.state.price);
		data.append("main_img", this.state.main_img);
		data.append("code", this.state.code);
		data.append("category_id", this.state.category_id);
		console.log(this.state.category_id);
		//----------------------------
		console.log(data)
		let res = await fetch('http://dinas.kz/server/public/api/admin/update-product', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		console.log(res);
		if (res.status === "ok") {
			alert("Продукт успешно отредактирован");
			window.location.reload();
		}
		else {
			alert("При редактировании произошла ошибка. Попробуйте ещё раз.");
		}
	}
	getProduct(props) {
		const productId = this.props.match.params.productId;
		console.log(productId);
		this.setState({
			productId: productId
		})
		fetch(`http://dinas.kz/server/public/api/admin/product/${productId}`)
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						product: result.product
					});
					console.log(this.state.product);
					const product = this.state.product;
					this.setState({
						id: product.id,
						count: product.count,
						title: product.title,
						description: product.description,
						price: product.price,
						main_img: product.main_img,
						code: product.code,
						category_id: product.category_id
					})
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	getCategories(props) {
		this.setState({ categories: this.props.categories });
	}
	componentDidMount() {
		this.getProduct();
		this.getCategories();
	}
	componentDidUpdate() {
		if (this.state.productId !== this.props.match.params.productId) {
			this.getProduct();
		}
		if (this.state.categories !== this.props.categories) {
			this.getCategories();
		}
	}
	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'file' ? target.files[0] : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}
	render() {
		if (this.state.categories !== undefined) {
			var categories = this.state.categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>);
		}
		// const productData = this.state.product[0];
		if (this.state.isLoaded === true) {
			const productData = this.state.product;
			var code = productData.code;
			var title = productData.title;
			var count = productData.count;
			var price = productData.price;
			var category_id = productData.category_id;
			var description = productData.description;
		}
		return (
			<Form onSubmit={this.handleSubmit}>
				<Form.Row>
					<Form.Group as={Col} controlId="formGridEmail">
						<Form.Label>Код товара</Form.Label>
						<Form.Control type="text" placeholder="Введите код товара" onChange={this.handleInputChange} defaultValue={code} name="code" />
					</Form.Group>

					<Form.Group as={Col} controlId="formGridPassword">
						<Form.Label>Изображение</Form.Label>
						<Form.File
							id="custom-file"
							label="Выберите изображение"
							data-browse="Выбрать"
							custom

							onChange={this.handleInputChange}
							name="main_img"
						/>
					</Form.Group>
				</Form.Row>
				<Form.Row>
					<Form.Group as={Col}>
						<Form.Label>Название товара</Form.Label>
						<Form.Control type="text" defaultValue={title} placeholder="Введите название товара" onChange={this.handleInputChange} name="title" />
					</Form.Group>

				</Form.Row>


				<Form.Row>
					<Form.Group as={Col}>
						<Form.Label>Цена товара</Form.Label>
						<Form.Control type="text" defaultValue={price} placeholder="Введите цену товара" onChange={this.handleInputChange} name="price" />
					</Form.Group>

					<Form.Group as={Col} controlId="formGridState">
						<Form.Label>Категория товара</Form.Label>
						<Form.Control as="select" onChange={this.handleInputChange} name="category_id" value={category_id}>
							{categories}
						</Form.Control>
					</Form.Group>

					<Form.Group as={Col} controlId="formGridZip">
						<Form.Label>Количество товара</Form.Label>
						<Form.Control type="text" defaultValue={count} placeholder="Введите количество товара" onChange={this.handleInputChange} name="count" />
					</Form.Group>
				</Form.Row>
				<Form.Group controlId="exampleForm.ControlTextarea1">
					<Form.Label>Описание товара</Form.Label>
					<Form.Control as="textarea" defaultValue={description} rows={3} onChange={this.handleInputChange} name="description" />
				</Form.Group>

				<Button variant="primary" type="submit">
					Обновить продукт
  				</Button>
			</Form>
		);
	}
}

class AddProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			products: [],
			categories: [],
			main_img: null
		};
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
	}
	async handleSubmit(event) {
		event.preventDefault();
		var data = new FormData();
		data.append("count", this.state.count);
		data.append("title", this.state.title);
		data.append("description", this.state.description);
		data.append("price", this.state.price);
		data.append("main_img", this.state.main_img);
		data.append("code", this.state.code);
		data.append("category_id", this.state.category_id);
		console.log(this.state.main_img)
		//----------------------------
		let res = await fetch('http://dinas.kz/server/public/api/admin/add-product', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		console.log(res);
		if (res.status === "ok") {
			alert("Товар успешно создан");
			window.location.reload();
		}
		else {
			if (res.msg === "Invalid login or password!") {
				alert("Не удалось создать товар. Попробуйте ещё раз.");
			}
		}
	}

	getCategories(props) {
		this.setState({ categories: this.props.categories });
	}

	componentDidMount() {
		this.getCategories();
	}
	componentDidUpdate() {
		if (this.state.categories !== this.props.categories) {
			this.getCategories();
		}
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'file' ? target.files[0] : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}
	render() {
		if (this.state.categories !== undefined) {
			var categories = this.state.categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>);
		}
		return (
			<Form onSubmit={this.handleSubmit}>
				<Form.Row>
					<Form.Group as={Col} controlId="formGridEmail">
						<Form.Label>Код товара</Form.Label>
						<Form.Control type="text" placeholder="Введите код товара" required onChange={this.handleInputChange} name="code" />
					</Form.Group>

					<Form.Group as={Col} controlId="formGridPassword">
						<Form.Label>Изображение</Form.Label>
						<Form.File
							id="custom-file"
							label="Выберите изображение"
							data-browse="Выбрать"
							custom
							required
							onChange={this.handleInputChange}
							name="main_img"
						/>
					</Form.Group>
				</Form.Row>
				<Form.Row>
					<Form.Group as={Col}>
						<Form.Label>Название товара</Form.Label>
						<Form.Control type="text" value={this.state.title} placeholder="Введите название товара" required onChange={this.handleInputChange} name="title" />
					</Form.Group>

				</Form.Row>


				<Form.Row>
					<Form.Group as={Col}>
						<Form.Label>Цена товара</Form.Label>
						<Form.Control type="text" value={this.state.price} placeholder="Введите цену товара" required onChange={this.handleInputChange} name="price" />
					</Form.Group>

					<Form.Group as={Col} controlId="formGridState">
						<Form.Label>Категория товара</Form.Label>
						<Form.Control as="select" required onChange={this.handleInputChange} name="category_id">
							{categories}
						</Form.Control>
					</Form.Group>

					<Form.Group as={Col} controlId="formGridZip">
						<Form.Label>Количество товара</Form.Label>
						<Form.Control type="text" value={this.state.count} placeholder="Введите количество товара" required onChange={this.handleInputChange} name="count" />
					</Form.Group>
				</Form.Row>
				<Form.Group controlId="exampleForm.ControlTextarea1">
					<Form.Label>Описание товара</Form.Label>
					<Form.Control as="textarea" value={this.state.description} rows={3} required onChange={this.handleInputChange} name="description" />
				</Form.Group>

				<Button variant="primary" type="submit">
					Добавить товар
  								</Button>
			</Form>
		);
	}
}

class Products extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			products: []
		};
	}

	componentDidMount() {
		this.getProducts();
		this.getCategories();
	}

	deleteProduct(id) {
		fetch(`http://dinas.kz/server/public/api/admin/delete-product/${id}`)
			.then(res => res.json())
			.then(
				(result) => {
					if (result.status === "ok") {
						alert("Товар с ID " + id + " был успешно удалён.");
						window.location.reload();
					}
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					alert("Во время удаления произошла ошибка.");
				}   
			)
	}

	getCategories(params) {
		fetch("http://dinas.kz/server/public/api/categories")
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						categories: result.categories
					});
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	getProducts(params) {
		fetch("http://dinas.kz/server/public/api/products")
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						products: result.products
					});
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	render() {
		const products = this.state.products;
		const tableItems = products.map((item) =>
			<tr key={item.id}>
				<td>{item.id}</td>
				<td>{item.title}</td>
				<td>{item.category_name}</td>
				<td>{item.main_img}</td>
				<td>{item.count}</td>
				<td>
					<DeleteIcon onClick={() => this.deleteProduct(item.id)} />
					<Link
						to={{
							pathname: `/admin/products/edit/${item.id}`,
						}}
					>
						<EditIcon />
					</Link>
				</td>
			</tr>);
		return (
			<Table striped bordered hover size="sm">
				<thead>
					<tr>
						<th>ID</th>
						<th>Наименование</th>
						<th>Категория</th>
						<th>Картинка</th>
						<th>Количество</th>
						<th>Действия</th>
					</tr>
					<tr>
						<td colSpan="6">
							<Route path="/admin/products/add" render={(props) => (
								<AddProduct {...props} categories={this.state.categories} />
							)} />
							<Route path="/admin/products/edit/:productId" render={(props) => (
								<EditProduct {...props} categories={this.state.categories} />
							)} />
						</td>
					</tr>
					<Route exact path="/admin/products">
						<tr>
							<td colSpan="6" className="text-center">
								<Link to="/admin/products/add">Создать товар</Link>
							</td>
						</tr>
					</Route>
				</thead>
				<tbody>
					{tableItems}
				</tbody>
			</Table >
		);
	}
}

export default Products;
