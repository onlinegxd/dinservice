import React from 'react';
import Table from 'react-bootstrap/Table';


class Requests extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			requests: []
		};
	}

	componentDidMount() {
		this.getRequests();
	}

	getRequests(params) {
		fetch("http://dinas.kz/server/public/api/callback")
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						requests: result.callback
					});
					console.log(result.callback);
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	render() {
		const requests = this.state.requests;
		const tableItems = requests.map((item) =>
			<tr key={item.id}>
				<td>{item.id}</td>
				<td>{item.name}</td>
				<td>{item.phone}</td>
				<td>{item.created_at}</td>
				{/* <td className="text-center">
					<Button className="mr-2" variant="danger" onClick={() => this.deleteCategory(item.id)}>Удалить</Button>
					<Button variant="info">Редактировать</Button>
				</td> */}
			</tr>);
		return (
			<Table striped bordered hover size="sm">
				<thead>
					<tr>
						<th>ID</th>
						<th>Имя</th>
						<th>Телефон</th>
						<th>Время создания</th>
					</tr>
				</thead>
				<tbody>
					{tableItems}
				</tbody>
			</Table>
		);
	}
}

export default Requests;
