import React from 'react';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';


class Users extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			users: []
		};

	}

	componentDidMount() {
		this.getUsers();
	}

	deleteUser(id) {
		fetch(`http://dinas.kz/server/public/api/auth/user/del/${id}`)
			.then(res => res.json())
			.then(
				(result) => {
					if (result.status === "ok") {
						alert("Пользователь с ID " + id + " был успешно удалён.");
						window.location.reload();
					}
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					alert("Во время удаления произошла ошибка.");
				}
			)
	}

	getUsers(params) {
		fetch("http://dinas.kz/server/public/api/admin/users")
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						users: result.users
					});
					console.log(result.users)
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	render() {
		const users = this.state.users;
		const tableItems = users.map((item) =>
			<tr key={item.id}>
				<td>{item.id}</td>
				<td>{item.fio}</td>
				<td>{item.phone}</td>
				<td>{item.email}</td>
				<td>{item.city}</td>
				<td>{item.address}</td>
				<td>{item.password}</td>
				<td className="text-center"><Button variant="danger" onClick={() => this.deleteUser(item.id)}  >Удалить</Button></td>
			</tr>);
		return (
			<Table striped bordered hover size="sm">
				<thead>
					<tr>
						<th>ID</th>
						<th>ФИО</th>
						<th>Телефон</th>
						<th>Email</th>
						<th>Город</th>
						<th>Адрес</th>
						<th>Пароль</th>
					</tr>
				</thead>
				<tbody>
					{tableItems}
				</tbody>
			</Table>
		);
	}
}

export default Users;
