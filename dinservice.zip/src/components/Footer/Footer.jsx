 import React from 'react';
import { NavLink } from 'react-router-dom';
import style from './css/Footer.module.css';


function Footer() {
	return (
		<footer className={style.footer}>
			<div className="container">
				<div className="row">
					{/* <!-- Значки на соц.сети --> */}
					<div className="col-lg-3 offset-lg-1 col-md-4 offset-md-0 col-sm-12 ">
						<h6 className="text-center">Мы в социальных сетях</h6>
						<div className="d-flex justify-content-center">
							<NavLink to="#"><img className="ml-0" src="img/icons/insta.png" alt="Instagramm"></img></NavLink>
							<NavLink to="#"><img src="img/icons/vk.png" alt="Vkontakte"></img></NavLink>
							<NavLink to="#"><img src="img/icons/whatsapp.png" alt="whatspapp"></img></NavLink>
							<NavLink to="#"><img src="img/icons/telegram.png" alt="Telegram"></img></NavLink>
						</div>
					</div>
					{/* <!-- Навигация --> */}
					<div className="col-lg-3 offset-lg-1 col-md-4 offset-md-0 col-sm-6 mt-md-0 mt-4 col-12 text-sm-left text-center">
						<h6>Навигация</h6>
						<ul className="mt-4">
							<li>Оптовым покупателям </li>
							<li>Сотрудничество</li>
							<li>Партнерство</li>
							<li>Вакансии</li>
							<li>Обратный отзыв</li>
						</ul>
					</div>
					{/* <!-- Свяжитесь с нами --> */}
					<div className="col-xl-3 offset-xl-1 col-md-4 offset-md-0 col-sm-6 mt-md-0 mt-4 col-12 text-sm-left text-center">
						<h6>Свяжитесь с нами</h6>
						<p className="mt-4">Казахстан, г. Жанаозен</p>
						<p>Пром.зона 2 строение 103А</p>
						<a href=" tel:+77057841534">
							<p className="mt-3">+7 705 784 1534</p>
						</a>
						<a href="tel:+77057841534">
							<p className="mb-5">+7 705 784 1534</p>
						</a>
					</div>
				</div>
			</div>
		</footer>
	);
}

export default Footer;