import React from 'react';
import style from './css/CatalogueMenu.module.css';
import theme from './../../../css/App.module.css';
import { NavLink } from "react-router-dom";
import $ from "jquery";

function toggleCatalogue(param) {
	$('.catalogueMenu__body').toggleClass('catalogueMenu__body_active');
	if ($('.catalogueMenu__body').hasClass('catalogueMenu__body_active')) {
		$('.catalogueMenu__body').fadeIn();
	}
	else {
		$('.catalogueMenu__body').fadeOut();
	}
}

function CatalogueMenu() {
	return (
		<div className={`container-fluid ${style.catalogueMenu__container}`}	>
			<div className={`row ${style.catalogueMenu}`}>
				<div className="offset-sm-2 col-sm-2 col-4 d-flex align-items-center">
					<img src="img/icons/burger-menu.png" alt="Burger Menu" onClick={toggleCatalogue}></img>
					<p className="pb-0">Каталог</p>
				</div>
				<div className="offset-xl-3 col-xl-2 offset-md-2 col-md-3 offset-sm-1 col-sm-4 col-4 d-flex align-items-center">
					<img src="img/icons/lorry.png" alt="Доставка и оплата"></img>
					<NavLink to="delivering">Доставка и оплата</NavLink>
				</div>
				<div className="col-lg-2 col-md-3 col-sm-3 col-4 d-flex align-items-center justify-content-center">
					<img src="img/icons/info.png" alt="О компании"></img>
					<NavLink to="about">О компании</NavLink>
				</div>
			</div>
			{/* Развёрнутый каталог */}
			<div className={`container catalogueMenu__body ${style.catalogueMenu__body}`}>
				<div className={`row ${style.catalogueMenu__goods}`}>
					<div className={`${theme.topLeftCorner}`}></div>
					<div className="col-sm-10 offset-sm-2">
						<div className="row">
							<div className="col-md-4">
								<h4>Запчасти</h4>
								<ul>
									<li><NavLink to="SearchOverall">Просмотр всех запчастей</NavLink></li>
									<li><NavLink to="SearchDetail">Поиск по номеру запчасти</NavLink></li>
									<li><NavLink to="SearchCar">Поиск по номеру кузова</NavLink></li>
									<li><NavLink to="catalogue">Оригинальные запчасти</NavLink></li>
									<li><NavLink to="SearchQuick">Запчасти для ТО</NavLink></li>
								</ul>
							</div>
							<div className="col-md-4">
								<h4>Обслуживание</h4>
								<ul>
									<li>Смазочные материалы</li>
									<li>Автохимия</li>
								</ul>
							</div>
							<div className="col-md-4">
								<h4>Полезное</h4>
								<ul>
									<li><NavLink to="#">Акции</NavLink></li>
									<li><NavLink to="news">Новости</NavLink></li>
									<li><NavLink to="#">Партнерам</NavLink></li>
									<li><NavLink to="#">Сертификаты</NavLink></li>
									<li><NavLink to="contacts">Контакты</NavLink></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}

export default CatalogueMenu;
