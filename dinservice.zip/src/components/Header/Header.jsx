import React from 'react';
import MainMenu from './MainMenu/MainMenu';
import CatalogueMenu from './CatalogueMenu/CatalogueMenu';

function Header(props) {
	return (
		<header>
			<MainMenu cart_length={props.cart_length} />
			<CatalogueMenu />
		</header >
	);
}

export default Header;
