import React from 'react';
import style from './css/BottomMenu.module.css';
import $ from "jquery";
import { NavLink } from 'react-router-dom';

function popup(visibility, window) {
	switch (visibility) {
		case 1:
			$(".popupWrapper").css("display", "flex");
			if (window === "register") {
				$(".popupWindow_register").show();
				$(".popupWindow_login").hide();
				$(".popupWindow_ordering").hide();

			}
			if (window === "login") {
				$(".popupWindow_login").show();
				$(".popupWindow_register").hide();
				$(".popupWindow_ordering").hide();
			}
			if (window === "order") {
				$(".popupWindow_ordering").show();
				$(".popupWindow_register").hide();
				$(".popupWindow_login").hide();
			}
			break;
		default:
			break;
		case 0:
			$(".popupWrapper").hide();
			if (window === "register") {
				$(".popupWindow_register").hide();
			}
			if (window === "login") {
				$(".popupWindow_login").hide();
			}
			if (window === "order") {
				$(".popupWindow_ordering").hide();
			}
			break;
	}
}

$(document).ready(function () {
	if (localStorage.getItem("user_data") !== null) {
		$("#login").hide();
		$("#account").show();
	}
	else {
		$("#login").show();
		$("#account").hide();
	}
});



function BottomMenu() {
	return (
		<div className={`row align-items-center ${style.menu__bottom} ${style.bottomMenu}`}>
			{/* Номера */}
			<div className={`offset-sm-1 col-md-4 col-lg-3 col-sm-6 order-first col-7 offset-0  ${style.bottomMenu__phone}`}>
				<div class="dropdown mb-3">
					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Смена языка
  					</button>
					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						<a class="dropdown-item active" href="#">RU</a>
						<a class="dropdown-item" href="#">KZ</a>
						<a class="dropdown-item" href="#">EN</a>
					</div>
				</div>
			</div>
			{/* Кнопка */}
			<div className="col-md-5 col-lg-4 order-1">
				<button className={`${style.bottomMenu__btn}`} onClick={() => { popup(1, 'order'); }}>ЗАКАЗАТЬ ЗВОНОК</button>
			</div>
			{/* Вход (в поледующем - личный кабинет) */}
			<div className={`offset-md-0 col-md-2 offset-lg-1 col-lg-3 col-sm-4 col-4 d-flex justify-content-end align-items-center order-md-last ${style.bottomMenu__login}`}>
				<img src="img/icons/login.png" alt="Вход"></img>
				<p onClick={() => { popup(1, 'login'); }} id="login">Вход</p>
				<NavLink id="account" className="pl-2" to="/account">Личный кабинет</NavLink>
			</div>
		</div>
	);
}

export default BottomMenu;
