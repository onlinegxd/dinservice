import React from 'react';
import style from './css/MainMenu.module.css';
import TopMenu from './TopMenu/TopMenu';
import BottomMenu from './BottomMenu/BottomMenu';
import { NavLink } from 'react-router-dom';


function MainMenu(props) {
	return (
		<div className={`container`}>
			<div className={`row`}>
				{/*  Логотип / Левая часть */}
				<div className="col-sm-2 d-flex d-sm-block justify-content-center">
					<NavLink to="/">
						<img className={style.menu__logo} src="img/logo.png" alt="логотип"></img>
					</NavLink>
				</div>
				{/* Двухуровневая менюшка / Правая часть */}
				<div className="col-sm-10">
					{/* Верхняя меню (Информация + корзина) */}
					<TopMenu cart_length={props.cart_length} />
					{/* Нижнее меню (номера + кнопка + личный кабинет) */}
					<BottomMenu />
				</div>
			</div>
		</div>
	);
}

export default MainMenu;
