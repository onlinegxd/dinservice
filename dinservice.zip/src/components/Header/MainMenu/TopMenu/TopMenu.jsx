import React from 'react';
import { NavLink } from 'react-router-dom';
import style from './css/TopMenu.module.css';

if (localStorage.getItem("cart") === null) {
	localStorage.setItem("cart", JSON.stringify([]));
}

function TopMenu(props) {
	return (
		< div className={`row align-items-center  ${style.topMenu}`} >
			{/* Почта */}
			< div className="offset-sm-1 col-xl-3 col-lg-4 h-100 d-none d-lg-flex align-items-center" >
				<p><a className={`${style.topMenu__mail}`} href="mailto:info@dinasservice.kz">info@dinasservice.kz</a></p>
			</div >
			{/* ТОО "Динас Сервис" */}
			< div className="col-xl-3 col-lg-4 col-md-5 offset-md-2 offset-lg-0 col-sm-7 col-6 h-100 d-flex align-items-center justify-content-center" >
				<p className={`${style.topMenu__company}`}>ТОО "ДинАс Сервис"</p>
			</div >
			{/* Наличие документов	 */}
			< div className="col-xl-3 col h-100 d-none d-xl-flex align-items-center" >
				<p className={`${style.topMenu__docs}`}>Наличие документов</p>
			</div >
			{/* Корзина */}
			< div className={`col-xl-2 col-lg-3 col-md-5 col-sm-5 col-6 d-flex align-items-center justify-content-center  ${style.topMenu__cart}`} >
				<img src="img/icons/cart.png" alt="Корзина"></img>
				<NavLink to="cart">
					<p>ИЗБРАННОЕ</p>
				</NavLink>
				<span>{props.cart_length}</span>
			</div >
		</div >
	);
}

export default TopMenu;
