import React from 'react';
import theme from './../../../css/App.module.css';
import style from './css/AccountPage.module.css';
import $ from "jquery";
import Cart from '../CartPage/Cart';

function settingsShow() {

	$('.accountPage__body').hide(); $('.accountPage__settings').fadeIn();
}

function bodyShow() {
	$('.accountPage__settings').hide(); $('.accountPage__body').fadeIn();
}

class Orders extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			orders: []
		};
	}

	componentDidMount() {
		if (localStorage.getItem("user_data") !== null) {
			var user_data_obj = JSON.parse(localStorage.getItem("user_data"));
			this.getOrders(user_data_obj.id);
		}
	}

	async getOrders(id) {
		var data = new FormData();
		data.append("user_id", id);
		let res = await fetch('http://dinas.kz/server/public/api/user/orders', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		if (res.status === "ok") {
			this.setState({ orders: res.orders });
		}
	}

	render() {
		const orders = this.state.orders;
		return (
			<tbody>
				{orders.map((order) =>
					<tr key={order.id}>
						<th className="text-center" scope="row">{order.id}</th>
						<td>
							<table>
								<thead>
									<tr>
										<td >ID</td>
										<td>Наименование</td>
										<td>Количество</td>
										<td>Цена</td>
									</tr>
								</thead>
								<tbody>
									{JSON.parse(order.cart).map((item) =>
										<tr key={item.id}>
											<td>{item.id}</td>
											<td>{item.name}</td>
											<td>{item.count}</td>
											<td>{item.price}</td>
										</tr>)}
								</tbody>
							</table>
						</td>
						<td className="text-center">
							{order.total_price}
						</td>
					</tr>)}
				<tr>
				</tr>
			</tbody>
		)
	}
}

class AccountPage extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			isLoaded: false,
			orders: [],
			user_data: {},
			orderSum: 0,
			user: {}
		};
		this.handleSubmit = this.handleSubmit.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'file' ? target.files[0] : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}

	getUser(params) {
		const userID = JSON.parse(localStorage.getItem("user_data")).id;
		fetch(`http://dinas.kz/server/public/api/admin/users/${userID}`)
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						user: result.user
					});
					console.log(result.user)
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	componentDidMount() {
		if (localStorage.getItem("user_data") !== null) {
			var user_data_obj = JSON.parse(localStorage.getItem("user_data"));
			this.setState({ user_data: user_data_obj });
		}
		this.getUser();
	}

	async handleSubmit(event) {
		event.preventDefault();
		var data = new FormData();
		data.append("id", this.state.user_data.id);
		this.state.address ? data.append("address", this.state.address) : data.append("address", this.state.user.address);
		this.state.city ? data.append("city", this.state.city) : data.append("city", this.state.user.city);
		this.state.fio ? data.append("fio", this.state.fio) : data.append("fio", this.state.user.fio);
		this.state.phone ? data.append("phone", this.state.phone) : data.append("phone", this.state.user.phone)
		this.state.email ? data.append("email", this.state.email) : data.append("email", this.state.user.email)
		//----------------------------
		let res = await fetch('http://dinas.kz/server/public/api/admin/update-user', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		console.log(res);
		if (res.status === "ok") {
			alert("Данные успешно обновлены");
			window.location.reload();
		}
		else {
			alert("При обновлении данных произошла ошибка.");
		}
	}

	render() {
		console.log(this.state.user);
		return (
			<main className={`${style.accountPage}`}>
				<div className="container">
					<div className={`${style.accountPage__container}`}>
						<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
						<h2>Личный кабинет</h2>
						<div className="row">
							<div className="col-md-8">
								<div className={` accountPage__body ${style.accountPage__body}`}>
									<h4>Избранное</h4>
									{/* <!-- Заголовки для таблицы --> */}
									<table className="table table-bordered">
										<thead>
											<tr>
												<th scope="col">Название</th>
												<th scope="col">Цена</th>
											</tr>
										</thead>
										<Cart cart={this.props.cart} handleCartChange={this.props.handleCartChange} />
									</table>
								</div>
								<div className={`accountPage__settings ${style.accountPage__settings}`}>
									<div className="row">
										<div className="col-sm-12">
											<form className="form d-flex flex-column" onSubmit={this.handleSubmit}>
												<input type="text" name="fio" className="form-control" placeholder="ФИО" required onChange={this.handleInputChange} defaultValue={this.state.user.fio}></input>
												<input type="text" name="address" className="form-control" placeholder="Адрес" required onChange={this.handleInputChange} defaultValue={this.state.user.address}></input>
												<input type="text" name="city" className="form-control" placeholder="Город" required onChange={this.handleInputChange} defaultValue={this.state.user.city}></input>
												<input type="email" name="email" className="form-control" placeholder="Email" required onChange={this.handleInputChange} defaultValue={this.state.user.email}></input>
												<input type="text" name="phone" className="form-control" placeholder="Телефон" required onChange={this.handleInputChange} defaultValue={this.state.user.phone}></input>
												<button className={`${theme.actionBtn} ${style.actionBtn}`}>Сохранить</button>
											</form>
										</div>
										{/* <div className="col-sm-6 d-flex flex-column">
											<input type="password" className="form-control" placeholder="Старый пароль"></input>
											<input type="password" className="form-control" placeholder="Новый пароль"></input>
											<input type="password" className="form-control" placeholder="Повторить пароль"></input>
											<button className={`${theme.actionBtn} ${style.actionBtn}`}>Смените пароль</button>
										</div> */}
									</div>
								</div>
							</div>
							<div className="col-md-4">
								<aside className={`${style.accountPage__sidebar}`}>
									<div className="row flex-column">
										<div className="col-12 mt-4 mt-md-0">
											<button className={`${theme.actionBtn}`} onClick={() => { localStorage.removeItem("user_data"); window.location.replace("/"); }}>Выйти</button>
										</div>
										<div className="col-12">
											<div >
												<p>Логин: <b>{JSON.parse(localStorage.getItem("user_data")).email}</b></p>
												<p>Бонусы: <b>0 ₸</b></p>
											</div>
										</div>
										<div className="col-12">
											<button className={`${theme.actionBtn}`}
												onClick={settingsShow}> Редактировать
													профиль</button>
										</div>
										<div className="col-12">
											<div >
												<p>Если у Вас возникли вопросы по заказу, дополнению или отмене заказа. Обратитесь в отдел
												продаж по номеру телефона <b>+7(707) 304 92 33. Мы с удовольствием Вам поможем. </b>
												</p>
											</div>
										</div>
										<div className="col-12">
											<button className={`${theme.actionBtn}`}
												onClick={bodyShow}>Избранные товары</button>
										</div>
									</div>
								</aside>
							</div>
						</div>
					</div>
				</div>
			</main >
		);
	}
}

export default AccountPage;
