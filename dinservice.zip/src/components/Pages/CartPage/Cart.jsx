import React from 'react';


if (localStorage.getItem("cart") === null) {
	localStorage.setItem("cart", JSON.stringify([]));
}



class CartItem extends React.Component {
	constructor(props) {
		super(props);
		this.state = { itemCount: this.props.amount, cart: this.props.cart };
		this.handleClick = this.handleClick.bind(this);
	}

	handleClick(counter, id) {
		var user_cart = this.props.cart;
		if (counter > 0) {
			this.setState({ itemCount: counter })
			let product = user_cart.find(item => item.item_id === id);
			product.amount = counter;
			localStorage.setItem("cart", JSON.stringify(user_cart))
		}
		else {
			let productID = user_cart.findIndex(item => item.item_id === id);
			user_cart.splice(productID, 1);
			localStorage.setItem("cart", JSON.stringify(user_cart));
		}
		user_cart = JSON.parse(localStorage.getItem("cart"));
		var totalSum = 0;
		for (let i = 0; i < user_cart.length; i++) {
			totalSum += (user_cart[i].price * user_cart[i].amount);
		}
		console.log(totalSum);
		this.props.handleSumChange(totalSum);
		this.props.handleCartChange(user_cart);
	}

	render() {
		return (
			<tr>
				<th scope="row">{this.props.name}</th>
				<td>{this.props.price}</td>
			</tr>
		);

	}
}

class Cart extends React.Component {
	constructor(props) {
		super(props);
		this.state = { sum: this.props.sum };

	}


	render() {
		var user_cart = this.props.cart;
		// user_cart === undefined ? user_cart = [] : user_cart = this.props.cart;
		if (user_cart.length > 0) {
			const mappedCart = user_cart.map((item) =>
				<CartItem cart={this.props.cart} handleCartChange={this.props.handleCartChange} handleSumChange={this.props.handleSumChange} key={item.item_id} id={item.item_id} name={item.name} amount={item.amount} price={item.price} />
			);
			return (
				<tbody>
					{ mappedCart}
				</tbody>
			);
		}
		else {
			return (
				<tbody>
					<tr>
						<th scope="row"></th>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
			);
			// user_cart.push({ "item_id": id, "amount": 1, "name": name, "price": price });
		}

	}
}

export default Cart;