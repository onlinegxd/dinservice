import React from 'react';
import theme from './../../../css/App.module.css';
import Cart from './Cart';
import style from './css/CartPage.module.css';

if (localStorage.getItem("cart") === null) {
	localStorage.setItem("cart", JSON.stringify([]));
}

// var user_cart = [];
var totalSum = 0;


class CartPage extends React.Component {
	constructor(props) {
		super(props);
		this.handleSend = this.handleSend.bind(this);
		totalSum = 0;
		for (let i = 0; i < this.props.cart.length; i++) {
			totalSum += (this.props.cart[i].price * this.props.cart[i].amount);
		}
		this.state = { sum: totalSum };
		this.handleSumChange = this.handleSumChange.bind(this);
	}

	handleSumChange(cart_sum) {
		this.setState({ sum: cart_sum });
	}

	handleSend(event) {
		event.preventDefault();
		window.location.replace("#/orderPage");
	}

	render() {
		return (
			<main className={`container  ${style.cartPage}`}>
				<div className="row">
					<div className="col-12">
						<div className={`${style.cartPage__body}`}>
							<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
							<h2>Избранное</h2>
							{/* <!-- Заголовки для таблицы --> */}
							<table className="table table-bordered">
								<thead>
									<tr>
										<th scope="col">Название</th>
										<th scope="col">Цена</th>
									</tr>
								</thead>
								<Cart cart={this.props.cart} handleCartChange={this.props.handleCartChange} sum={this.state.sum} handleSumChange={this.handleSumChange} />
							</table>
						</div>
					</div>
				</div>
			</main>
		);
	}
}

export default CartPage;
