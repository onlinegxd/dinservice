import React from 'react';
import style from './css/CataloguePage.module.css';
import theme from './../../../css/App.module.css';

function CataloguePage() {
	return (
		<main className={`${style.cataloguePage}`}>
			<div className="container-fluid">
				<div className={`${style.cataloguePage__container}`}>
					<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
					<h2>Каталог</h2>
					<div className="row justify-content-around">
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/alfa-romeo.jpg" alt=""></img>
								</div>
								<p>Alfa Romeo</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/chevrolet.jpg" alt=""></img>
								</div>
								<p>Chevrolet</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/audi.jpg" alt=""></img>
								</div>
								<p>Audi</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/bmw.jpg" alt=""></img>
								</div>
								<p>BMW</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/cadillac.jpg" alt=""></img>
								</div>
								<p>Cadillac</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/chrysler.jpg" alt=""></img>
								</div>
								<p>Chrysler</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/citroen.jpg" alt=""></img>
								</div>
								<p>Citroen</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/daewoo.jpg" alt=""></img>
								</div>
								<p>Daewoo</p>
							</div>
						</div>
						<div className="col-md-1 pr-0 pl-0">
							<div className={`${style.cataloguePage__item}`}>
								<div className={`${style.cataloguePage__img}`}>
									<img src="img/catalogue/dodge.jpg" alt=""></img>
								</div>
								<p>Dodje</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main >
	);
}

export default CataloguePage;
