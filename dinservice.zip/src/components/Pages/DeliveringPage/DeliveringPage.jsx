import React from 'react';
import theme from './../../../css/App.module.css';
import style from './css/DeliveringPage.module.css';

function DeliveringPage() {
	return (
		<main className={`${style.deliveringPage}`}>
			<div className="container">
				<div className="row">
					<div className="col-12">
						<div className={`${style.deliveringPage__text}`}>
							<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
							<h2>Условия доставки и оплаты</h2>
							<p>Доставка осуществляется только по предоплате</p>
							<h4>Способы доставки</h4>
							<ul>
								<li>Транспортная компания по всему Казахстану</li>
								<li>Оставьте заявку на сайте или позвоните по нашим
								контактам и мы проконсультируем по всем деталям</li>
								<li>Самовывоз г.Жанаозен пром.зона 2, строение 103А</li>
							</ul>
							<h4>Способы оплаты</h4>
							<ul>
								<li>Оплата картой</li>
								<li>Оплата картой возможна как по терминалу так же по номеру</li>
								<li>Безналичный расчет</li>
								<li>Оплата возможна по реквизитам компании,работаем по предоплате</li>
								<li>Наличными можно оплатить по месту г.Жанаозен, пром.зона 2, строение 103А</li>
							</ul>
							<h4>Регионы доставки</h4>
							<ul>
								<li>Казахстан, все регионы</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</main>
	);
}

export default DeliveringPage;
