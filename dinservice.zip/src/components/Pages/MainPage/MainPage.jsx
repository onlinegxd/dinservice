import React from 'react';
import theme from './../../../css/App.module.css';
import style from './css/MainPage.module.css';

function MainPage() {
	return (
		<main className="mainPage">
			{/* <!-- Скидки и прочее --> */}
			<div className="container-fluid d-none d-lg-block">
				<div className={`row  ${style.mainPage__sale}`}>
					<div className={`offset-sm-6 col-sm-6  ${style.mainPage__bg}`}>
						<h4>НОВОСТИ ЛИБО АКЦИЯ</h4>
						<h2>ЗАГОЛОВОК</h2>
						<h3>информация</h3>
						<h2>ЦЕНА</h2>
					</div>
				</div>
			</div>
			{/* <!-- Поиск --> */}
			<div className={`container  ${style.searchBlock}`}>
				{/* <!--Надпись поиск детали --> */}
				<div className="row">
					<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
					<div className={`col-lg-3 col-sm-5 ${style.searchBlock__preview}`}>
						<img src="img/icons/search.png" alt="Поиск"></img>
						<h5>ПОИСК ДЕТАЛИ</h5>
					</div>
				</div>
				{/* <!-- Поиск детали (поля ввода) --> */}
				<div className={`row align-items-center ${style.searchBlock__body}`}>
					{/* <!-- Текстовые поля + кнопка --> */}
					<div className="col-12">
						<div className="row no-gutters">
							{/* <!-- VIN-номер --> */}
							<div className="col-sm-4">
								<label  >VIN-номер</label> <br></br>
								<input type="text"></input>
							</div>
							{/* <!-- Артикуль --> */}
							<div className="col-sm-4">
								<label  >Артикул</label> <br></br>
								<input type="text"></input>
							</div>
							{/* <!-- Кнопка поиск --> */}
							<div className="col-sm-4">
								<button className={`${theme.actionBtn}`}>Поиск</button>
							</div>
						</div>
					</div>
					{/* <!-- Чекбоксы --> */}
					<div className={`col-lg-7 col-sm-12 ${style.searchBlock__categories}`}>
						<label  ><input type="checkbox" name="" id=""></input>Техническое обслуживание</label>
						<label  ><input type="checkbox" name="" id=""></input>Лекговые</label>
						<label  ><input type="checkbox" name="" id=""></input>Коммерческие</label>
						<label  ><input type="checkbox" name="" id=""></input>Мото</label>
					</div>
				</div>
			</div>
			{/* <!-- Заголовок секции Акции --> */}
			<div className="container-fluid">
				<div className="row">
					<div className={`col-sm-10 ${style.mainPage__sectionHeading}`}>
						<h5>АКЦИИ</h5>
					</div>
				</div>
			</div>
			{/* <!-- Секция с тремя карточками акций --> */}
			<div className="container">
				<div className="row">
					<div className="col-sm-10 offset-sm-1">
						<div className="row flex-nowrap">
							<div className={`col-lg-4 col-md-6 ml-md-0 ${style.saleCard}`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЦЕНА</h5>
								<h6>НАЗВАНИЕ ЗАПЧАСТИ</h6>
								<div className={`${style.saleCard__corner}`}>
									<small>скидка</small> <br />
									<b>30%</b>
								</div>
							</div>
							<div className={`col-lg-4 col-md-6 d-none d-md-flex ${style.saleCard}`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЦЕНА</h5>
								<h6>НАЗВАНИЕ ЗАПЧАСТИ</h6>
								<div className={`${style.saleCard__corner}`}>
									<small>скидка</small> <br />
									<b>30%</b>
								</div>
							</div>
							<div className={`col-sm-4 d-none d-lg-flex ${style.saleCard}`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЦЕНА</h5>
								<h6>НАЗВАНИЕ ЗАПЧАСТИ</h6>
								<div className={`${style.saleCard__corner}`}>
									<small>скидка</small> <br />
									<b>30%</b>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			{/* <!-- Заголовок секции Сопутствующие товары --> */}
			<div className="container-fluid">
				<div className="row">
					<div className={`col-sm-10 ${style.mainPage__sectionHeading}`}>
						<h5>СОПУТСТВУЮЩИЕ ТОВАРЫ</h5>
					</div>
				</div>
			</div>
			{/* <!-- Сопутствующие товары --> */}
			<div className="container">
				<div className={`row  ${style.mainPage__goods}`}>
					<div className={`${theme.topLeftCorner}`}></div>
					<div className="col-sm-10 offset-lg-2 offset-md-0">
						<div className="row">
							<div className="col-md-4 col-sm-6">
								<h4>Инструменты</h4>
								<ul>
									<li>Домкраты</li>
									<li>Наборы</li>
									<li>Ручной инструмент</li>
								</ul>
							</div>
							<div className="col-md-4 col-sm-6">
								<h4>Аксессуары</h4>
								<ul>
									<li>Дефлекторы</li>
									<li>Коврики</li>
									<li>Защита</li>
								</ul>
							</div>
							<div className="col-md-4 col-sm-6">
								<h4>Автохимия</h4>
								<ul>
									<li>Смазки</li>
									<li>Присадки</li>
									<li>Ароматизаторы</li>
								</ul>
							</div>
							<div className="col-md-4 col-sm-6 offset-lg-0 offset-md-1">
								<h4>Щётки стеклоочистителя</h4>
								<ul>
									<li>Бескаркасные</li>
									<li>Каркасные</li>
									<li>Гибридные</li>
								</ul>
							</div>
							<div className="col-md-4 col-sm-6 offset-lg-0 offset-md-3">
								<h4>Электрооборудование</h4>
								<ul>
									<li>Аккумуляторы</li>
									<li>Лампы и свет</li>
									<li>Видеорегистраторы</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			{/* <!-- Заголовок секции Новости --> */}
			<div className="container-fluid">
				<div className="row">
					<div className={`col-sm-10 ${style.mainPage__sectionHeading}`}>
						<h5>НОВОСТИ</h5>
					</div>
				</div>
			</div>
			{/* <!-- Секция новости --> */}
			<div className="container">
				<div className="row">
					<div className="col-sm-10 offset-sm-1">
						<div className="row flex-nowrap">
							<div className={`col-lg-4 col-md-6 ml-md-0 ${style.saleCard}`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЦЕНА</h5>
								<h6>НАЗВАНИЕ ЗАПЧАСТИ</h6>
								<div className={`${style.saleCard__corner}`}>
									<small>скидка</small> <br />
									<b>30%</b>
								</div>
							</div>
							<div className={`col-lg-4 col-md-6 d-none d-md-flex ${style.saleCard}`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЦЕНА</h5>
								<h6>НАЗВАНИЕ ЗАПЧАСТИ</h6>
								<div className={`${style.saleCard__corner}`}>
									<small>скидка</small> <br />
									<b>30%</b>
								</div>
							</div>
							<div className={`col-sm-4 d-none d-lg-flex ${style.saleCard}`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЦЕНА</h5>
								<h6>НАЗВАНИЕ ЗАПЧАСТИ</h6>
								<div className={`${style.saleCard__corner}`}>
									<small>скидка</small> <br />
									<b>30%</b>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
	);
}

export default MainPage;
