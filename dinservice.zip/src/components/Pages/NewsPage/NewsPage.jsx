import React from 'react';
import style from './css/NewsPage.module.css';
import theme from './../../../css/App.module.css';
import { NavLink } from 'react-router-dom';


function NewsPage() {
	return (
		<main className={`${style.newsPage}`}>
			<div className="container">
				<div className="row">
					<div className="col-12">
						<div className={`${style.newsPage__text} pb-4`}>
							<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
							<h2 className="text-center">Новости</h2>
						</div>
					</div>
				</div>
				<div className="row justify-content-center">
					<div className="col-sm-10">
						<div className="row  ">
							<div className={`${style.newsCard} col-sm-4`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЗАГОЛОВОК</h5>
								<NavLink to="#">
									<h6 className="text-right pr-2">ПОДРОБНЕЕ...</h6>
								</NavLink>
							</div>
							<div className={`${style.newsCard} col-sm-4`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЗАГОЛОВОК</h5>
								<NavLink to="#">
									<h6 className="text-right pr-2">ПОДРОБНЕЕ...</h6>
								</NavLink>
							</div>
							<div className={`${style.newsCard} col-sm-4`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЗАГОЛОВОК</h5>
								<NavLink to="#">
									<h6 className="text-right pr-2">ПОДРОБНЕЕ...</h6>
								</NavLink>
							</div>
							<div className={`${style.newsCard} col-sm-4`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЗАГОЛОВОК</h5>
								<NavLink to="#">
									<h6 className="text-right pr-2">ПОДРОБНЕЕ...</h6>
								</NavLink>
							</div>
							<div className={`${style.newsCard} col-sm-4`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЗАГОЛОВОК</h5>
								<NavLink to="#">
									<h6 className="text-right pr-2">ПОДРОБНЕЕ...</h6>
								</NavLink>
							</div>
							<div className={`${style.newsCard} col-sm-4`}>
								<h4>ФОТО</h4>
								<p>Краткое описание</p>
								<h5>ЗАГОЛОВОК</h5>
								<NavLink to="#">
									<h6 className="text-right pr-2">ПОДРОБНЕЕ...</h6>
								</NavLink>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
	);
}

export default NewsPage;
