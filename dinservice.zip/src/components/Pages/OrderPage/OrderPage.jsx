import React from 'react';
import theme from './../../../css/App.module.css';
import style from './css/OrderPage.module.css';
import $ from "jquery";


if (localStorage.getItem("cart") === null) {
	localStorage.setItem("cart", JSON.stringify([]));
}

var user_cart = localStorage.getItem("cart");
var totalSum = 0;
for (let i = 0; i < user_cart.length; i++) {
	totalSum += (user_cart[i].price * user_cart[i].amount);
}

function popup(visibility, window) {
	switch (visibility) {
		case 1:
			$(".popupWrapper").css("display", "flex");
			if (window === "register") {
				$(".popupWindow_register").show();
				$(".popupWindow_login").hide();
				$(".popupWindow_ordering").hide();

			}
			if (window === "login") {
				$(".popupWindow_login").show();
				$(".popupWindow_register").hide();
				$(".popupWindow_ordering").hide();
			}
			if (window === "order") {
				$(".popupWindow_ordering").show();
				$(".popupWindow_register").hide();
				$(".popupWindow_login").hide();
			}
			break;
		default:
			break;
		case 0:
			$(".popupWrapper").hide();
			if (window === "register") {
				$(".popupWindow_register").hide();
			}
			if (window === "login") {
				$(".popupWindow_login").hide();
			}
			if (window === "order") {
				$(".popupWindow_ordering").hide();
			}
			break;
	}
}


class CartItem extends React.Component {

	render() {
		return (
			<tr>
				<th scope="row">{this.props.name}</th>
				<td>
					<p>{this.props.amount}</p>
				</td>
				<td>{this.props.price}</td>
				<td>{this.props.price * this.props.amount}</td>
			</tr>
		);

	}
}

class Cart extends React.Component {

	render() {
		var user_cart = JSON.parse(localStorage.getItem("cart"));
		console.log(user_cart);
		if (user_cart.length > 0) {
			const mappedCart = user_cart.map((item) =>
				<CartItem key={item.item_id} name={item.name} amount={item.amount} price={item.price} />
			);
			return (
				<tbody>
					{ mappedCart}
				</tbody>
			);
		}
		else {
			return (
				<tbody>
					<tr>
						<th scope="row"></th>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
			);
			// user_cart.push({ "item_id": id, "amount": 1, "name": name, "price": price });
		}

	}
}

class UserData extends React.Component {
	constructor(props) {
		super(props);
		this.state = { user: {} }
	}

	getUser(params) {
		const userID = JSON.parse(localStorage.getItem("user_data")).id;
		fetch(`http://dinas.kz/server/public/api/admin/users/${userID}`)
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						user: result.user
					});
					console.log(result.user)
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}
	componentDidMount() {
		this.getUser();
	}


	render() {
		return (
			<div className="col-md-6">
				<h3>Данные пользователя:</h3>
				<h4 className="mt-4"><b>ФИО: </b>{this.state.user.fio}</h4>
				<h4 className="mt-4"><b>Город: </b>{this.state.user.city}</h4>
				<h4 className="mt-4"><b>Адрес: </b>{this.state.user.address}</h4>
				<h4 className="mt-4"><b>Email: </b>{this.state.user.email}</h4>
				<h4 className="mt-4"><b>Номер: </b>{this.state.user.phone}</h4>
			</div>
		)
	}
}

class OrderPage extends React.Component {
	constructor(props) {
		super(props);
		this.handleSend = this.handleSend.bind(this);

	}


	async handleSend(event) {
		event.preventDefault();
		const data = new FormData();
		if (localStorage.getItem("user_data") !== null) {
			var user_data_obj = JSON.parse(localStorage.getItem("user_data"));
		}
		data.append("address", user_data_obj.address);
		data.append("city", user_data_obj.city);
		data.append("phone", user_data_obj.phone);
		data.append("fio", user_data_obj.fio);
		data.append("email", user_data_obj.email);
		data.append("user_id", user_data_obj.id);
		const cart_for_order = this.props.cart.map((product) => ({ "id": product.item_id, "count": product.amount, "name": product.name, "price": product.price }));
		totalSum = 0;
		for (let i = 0; i < this.props.cart.length; i++) {
			totalSum += (this.props.cart[i].price * this.props.cart[i].amount);
		}
		data.append("total_price", totalSum);
		data.append("cart", JSON.stringify(cart_for_order));
		console.log(cart_for_order);
		let res = await fetch('http://dinas.kz/server/public/api/order/add', {
			method: 'POST',
			ContentType: 'application/json',
			body: data
		});
		res = await res.json();
		if (res.status === "ok") {
			alert("Ваш заказ успешно оформлен. Сейчас Вы будете перенаправлены на страницу для оплаты.");
			window.open(res.payment_url, '_blank');
			localStorage.setItem("cart", JSON.stringify([]));
			window.location.reload();
		} else {
			alert("При оформлении заказа произошла ошибкаю. Попробуйте снова");
		}
		console.log(res);
	}

	render() {
		if (this.props.cart !== undefined) {
			totalSum = 0;
			for (let i = 0; i < this.props.cart.length; i++) {
				totalSum += (this.props.cart[i].price * this.props.cart[i].amount);
			}

		}
		return (
			<main className={`container  ${style.orderPage}`}>
				<div className="row">
					<div className="col-12">
						<div className={`${style.orderPage__body}`}>
							<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
							<h2>Оформление заказа</h2>
							{/* <!-- Заголовки для таблицы --> */}
							<div className="row">
								{localStorage.getItem("user_data") !== null ? <UserData /> : <div className="col-md-6"><h4>Вы не вошли в систему.Чтобы оформить заказ войдите в свой аккаунт или создайте новый.</h4><button className={`${theme.actionBtn}`} onClick={() => { popup(1, 'login'); }}>Войти в аккаунт</button></div>}
								<div className="col-md-6">
									<h3>
										Вы заказали:
									</h3>
									<table className="table table-bordered">
										<thead>
											<tr>
												<th scope="col">Название</th>
												<th scope="col">Количество</th>
												<th scope="col">Цена</th>
												<th scope="col">Сумма</th>
											</tr>
										</thead>
										<Cart />
									</table>
									<div className="row">
										<div className="col-12">
											<p>Сумма <i>{totalSum}</i></p>
											<p>Скидка <i>0</i></p>
											<p><b>Общая сумма заказа</b> <i>{totalSum}</i></p>
											{localStorage.getItem("user_data") !== null ? <button className={`${theme.actionBtn}`} onClick={this.handleSend} >Перейти к оплате</button> : <button className={`${theme.actionBtn}`} onClick={this.handleSend} disabled>Перейти к оплате</button>}

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>
		);
	}
}

export default OrderPage;
