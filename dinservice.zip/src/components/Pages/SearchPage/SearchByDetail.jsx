import React from 'react';
import style from './css/SearchPage.module.css';
import theme from './../../../css/App.module.css';

function SearchByDetail() {
	return (
		<div className={`${style.searchPage__container} ${style.searchPage__container_detail} searchPage__container_detail`}>
			<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
			<h2>Поиск детали по номеру запчасти</h2>
			<div className="row">
				<div className="col-sm-6">
					<input type="text" name="" id="" placeholder="Номер запчасти" />
					<button className={`${theme.actionBtn}`}><svg width="1em" height="1em" viewBox="0 0 16 16" className="bi bi-search" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
						<path fillRule="evenodd" d="M10.442 10.442a1 1 0 0 1 1.415 0l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1 1 0 0 1 0-1.415z" />
						<path fillRule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
					</svg>Поиск</button>
				</div>
				<div className="col-sm-6">
					<p><b>Номер запчасти</b>  - маркировка завода-изготовителя, предназначенная для идентификации детали автомобиля.
Наиболее простой способ узнать номер запчасти - найти заводскую маркировку на поверхности детали.</p>
					<img src="img/search/search_by_detail.jpg" alt="" />
				</div>
			</div>
		</div>
	);
}



export default SearchByDetail;
