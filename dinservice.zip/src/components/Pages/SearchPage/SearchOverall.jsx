import React from 'react';
import style from './css/SearchPage.module.css';
import theme from './../../../css/App.module.css';
import $ from "jquery";
import { Link } from 'react-router-dom';


class Card extends React.Component {
	addToCart(id, name, price) {
		var user_cart = JSON.parse(localStorage.getItem("cart"));
		var inCart = false;
		if (user_cart.length > 0) {
			for (let i = 0; i < user_cart.length; i++) {
				let cart_item = user_cart[i].item_id;
				if (id === cart_item) {
					$('#cartError').modal();
					inCart = true;
				}
			}
		}
		if (inCart === false) {
			user_cart.push({ "item_id": id, "amount": 1, "name": name, "price": price });
		}
		this.props.handleCartChange(user_cart);
		localStorage.setItem("cart", JSON.stringify(user_cart));
	}

	render() {
		const item = this.props.item;
		let canSell = "Нет в наличии";
		if (item.count > 0) {
			canSell = "Есть в наличии"
		}
		return (
			<div className="col-md-4 mt-3">
				<div className="card h-100" >
					{item.main_img === null ? <img src="img/search/nophoto.png" className="card-img-top" alt="фотография отсутвует"></img> : <img src={item.main_img} className="card-img-top" alt={item.title}></img>}
					<div className="card-body">
						<h5 className="card-title">{item.title}</h5>
						<h5 className="card-title">{item.price} т </h5>
						<h6 className="card-subtitle text-danger">{canSell}</h6>
						<p className="card-text">{item.description}</p>
						<Link href="#" className="btn btn-danger" onClick={() => { this.addToCart(item.id, item.title, item.price); }}>Добавить в избранное</Link>
					</div>
				</div>
			</div>
		);
	}

}

class OverallSearchResults extends React.Component {
	constructor(props) {
		super(props);
		this.changePage = this.changePage.bind(this);
		this.getProducts = this.getProducts.bind(this);
		this.state = {
			error: null,
			isLoaded: false,
			products: [],
			productsAmount: 0,
			currentPage: 0,
			countRequest: "http://dinas.kz/server/public/api/products",
			request: "http://dinas.kz/server/public/api/products/1/21"
		};
	}

	changePage(page) {
		this.setState({ currentPage: page, request: `http://dinas.kz/server/public/api/products/${page}/21` });
		this.getProducts(page);
	}

	getProducts(page) {
		fetch(`http://dinas.kz/server/public/api/products/${page}/21`)
			.then(res => res.json())
			.then(
				(result) => {
					this.setState({
						isLoaded: true,
						products: result.products
					});
				},
				// Примечание: важно обрабатывать ошибки именно здесь, а не в блоке catch(),
				// чтобы не перехватывать исключения из ошибок в самих компонентах.
				(error) => {
					this.setState({
						isLoaded: true,
						error
					});
				}
			)
	}

	componentDidMount() {
		this.getProducts(1);
	}
	render() {
		const products = this.state.products;
		const items = products.map((item) =>
			<Card item={item} key={item.id} cart={this.props.cart} handleCartChange={this.props.handleCartChange} />);
		return (
			<div className="row">
				{items}
				<div className="col-12 mt-5 d-flex justify-content-center">
					<nav aria-label="Page navigation example">
						<ul className="pagination justify-content-end">
							<li className={this.state.currentPage === 21 ? "page-item disabled" : "page-item"}>
								<Link className="page-link" href="#" tabIndex="-1" aria-disabled="true" onClick={() => this.changePage(this.state.currentPage - 21)}>Предыдущая</Link>
							</li>
							{/* <li className="page-item"><a className="page-link" href="#">1</a></li>
							<li className="page-item"><a className="page-link" href="#">2</a></li>
							<li className="page-item"><a className="page-link" href="#">4</a></li>
							<li className="page-item"><a className="page-link" href="#">5</a></li>
							<li className="page-item"><a className="page-link" href="#">6</a></li>
							<li className="page-item"><a className="page-link" href="#">7</a></li>
							<li className="page-item"><a className="page-link" href="#">8</a></li>
							<li className="page-item"><a className="page-link" href="#">9</a></li>
							<li className="page-item"><a className="page-link" href="#">10</a></li>
							<li className="page-item"><a className="page-link" href="#">11</a></li>
							<li className="page-item"><a className="page-link" href="#">12</a></li> */}
							<li className={this.state.currentPage === 23 ? "page-item disabled" : "page-item"}>
								<Link className="page-link" href="#" onClick={() => this.changePage(this.state.currentPage + 21)}>Следующая</Link>
							</li>
						</ul>
					</nav>
				</div>
			</div>)
	}
}



class SearchOverall extends React.Component {
	render() {
		return (
			<div className={`${style.searchPage__container} ${style.searchPage__container_car} searchPage__container_car`}>
				<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
				<h2>Общие результаты</h2>
				<div className="row">
					{/* Настройка результатов поиска */}
					{/* <div className="col-lg-3">
						<div className="accordion" id="accordionExample">
							<div className="card">
								<div className="card-header bg-danger" id="headingOne">
									<h5 className="mb-0">
										<button className="btn  btn-danger" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
											Цена</button>
									</h5>
								</div>
	
								<div id="collapseOne" className="collapse show" aria-labelledby="headingOne">
									<div className="card-body">
										<div className="form-row">
											<div className="form-group col-md-6">
												<label for="inputEmail4">От</label>
												<input type="text" className="form-control" id="inputEmail4" value="0" ></input>
											</div>
											<div className="form-group col-md-6">
												<label for="inputPassword4">До</label>
												<input type="text" className="form-control" id="inputPassword4" value="0"></input>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div className="card">
								<div className="card-header bg-danger" id="headingTwo">
									<h5 className="mb-0">
										<button className="btn btn-danger collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
											Бренд</button>
									</h5>
								</div>
								<div id="collapseTwo" className="collapse" aria-labelledby="headingTwo">
									<div className="card-body">
										<div className="form-check">
											<input className="form-check-input" type="checkbox" value="" id="defaultCheck1"></input>
											<label className="form-check-label" for="defaultCheck1">Бренд 1</label>
										</div>
										<div className="form-check">
											<input className="form-check-input" type="checkbox" value="" id="defaultCheck2"></input>
											<label className="form-check-label" for="defaultCheck2">Бренд 1</label>
										</div></div>
								</div>
							</div>
						</div>
					</div> */}
					{/* Результаты поиска по базе */}
					<div className="col-12">
						<div className="row">
							{/* <div className="col-md-6">
								<select className="custom-select">
									<option selected>Сортировать по </option>
									<option value="1">Сначала дешевле</option>
									<option value="2">Сначала дороже</option>
									<option value="3">По популярности</option>
								</select>
							</div> */}
							<div className="col-12">
								<div className="card mt-3">
									<div className="card-header text-white bg-danger">Результаты поиска</div>
									<div className="card-body">
										<OverallSearchResults cart={this.props.cart} handleCartChange={this.props.handleCartChange} />
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		);
	}
}



export default SearchOverall;
