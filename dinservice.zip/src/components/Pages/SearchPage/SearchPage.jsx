import React from 'react';
import style from './css/SearchPage.module.css';
import { BrowserRouter, HashRouter, Route } from "react-router-dom";
import SearchByCar from './SearchByCar';
import SearchByDetail from './SearchByDetail';
import SearchResult from './SearchResult';
import SearchQuick from './SearchQuick';
import SearchOverall from './SearchOverall';

class SearchPage extends React.Component {
	render() {
		return (
			<main className={`${style.searchPage}`}>
				<div className="container">

					<HashRouter>
						<Route path='/SearchQuick' component={SearchQuick} />
						<Route path='/SearchDetail' component={SearchByDetail} />
						<Route path='/SearchCar' component={SearchByCar} />
						<Route path='/SearchResult' component={SearchResult} />
						<Route path='/SearchOverall' render={() => <SearchOverall cart={this.props.cart} handleCartChange={this.props.handleCartChange} />} />
					</HashRouter>
				</div>
			</main >
		);
	}
}

export default SearchPage;
