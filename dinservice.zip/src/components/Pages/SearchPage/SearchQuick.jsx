import React from 'react';
import style from './css/SearchPage.module.css';
import theme from './../../../css/App.module.css';
import { Link, NavLink } from 'react-router-dom';

function SearchQuick() {
	return (
		<div className={`${style.searchPage__container} ${style.searchPage__container_car} searchPage__container_car`}>
			<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
			<ul className="nav nav-tabs" id="myTab" role="tablist">
				<li className="nav-item" role="presentation">
					<a className="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Поиск по группам</a>
				</li>
				<li className="nav-item" role="presentation">
					<a className="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Поиск по иллюстрациям</a>
				</li>
			</ul>
			<div className="tab-content" id="myTabContent">
				{/* Поиск по категориям */}
				<div className="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
					<a className="" data-toggle="collapse" href="#parts-group-1" role="button" aria-expanded="false" aria-controls="parts-group-1">Двигатель</a>
					<li className="collapse" id="parts-group-1">
						<Link href="#">Прокладки</Link>
					</li>
					<li className="collapse" id="parts-group-1">
						<a data-toggle="collapse" href="#parts-group-2" role="button" aria-expanded="false" aria-controls="parts-group-2">Системы подачи воздуха</a>
						<ul className="collapse" id="parts-group-2">
							<li><NavLink to="#">Корпус Воздушного Фильтра</NavLink></li>
							<li><NavLink to="#">Коллектор Впускной</NavLink></li>
							<li><NavLink to="#">Регулирование, Управление</NavLink></li>
						</ul>
					</li>
				</div>
				{/* Поиск по иллюстрациям */}
				<div className="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
					<div className="row pt-3">
						<div className="col-sm-4">
							<div className="list-group" id="list-tab" role="tablist">
								<a className="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Двигатель</a>
								<a className="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">Топливная система</a>
							</div>
						</div>
						<div className="col-sm-8">
							<div className="tab-content" id="nav-tabContent">
								<div className="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
									<div className="row">
										<div className="col-md-6"><div className="card ">
											<img src="https://img.avtosoft.net/INFINITI201809/250/US/F1_201809_007_400_400A_001.gif?s=7469&k=6c68eefa81ceb1dd4d224beb0bb3d743" className="card-img-top" alt="..."></img>
											<div className="card-body">
												<h5 className="card-title font-weight-bold">400A 001</h5>
												<p className="card-text">Переднй мост</p>
											</div>
										</div></div>
										<div className="col-md-6"><div className="card ">
											<img src="https://img.avtosoft.net/INFINITI201809/250/US/F1_201809_007_400_400A_001.gif?s=7469&k=6c68eefa81ceb1dd4d224beb0bb3d743" className="card-img-top" alt="..."></img>
											<div className="card-body">
												<h5 className="card-title font-weight-bold">401A 001</h5>
												<p className="card-text">Передняя подвеска</p>
											</div>
										</div></div>
									</div>
								</div>
								<div className="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
									<p>Детали для топливного бака</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}



export default SearchQuick;
