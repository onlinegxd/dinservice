import React from 'react';
import style from './css/SearchPage.module.css';
import theme from './../../../css/App.module.css';
import { NavLink } from 'react-router-dom';

function SearchResult() {
	return (
		<div className={`${style.searchPage__container} ${style.searchPage__container_car} searchPage__container_car`}>
			<div className={`${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
			<h2>Результаты поиска по номер ff8d4f47d5</h2>
			<div className="row">
				<div className="col-md-3">
					<div className="card">
						<div className="card-header bg-danger text-center text-white font-weight-bold">INFINITI FX35/45</div>
						<div className="card-body">
							<h6 className="card-title mb-0">Дата производства:</h6>
							<p className="card-text text-primary mb-0">12.2005</p>
							<h6 className="card-title mb-0">Двигатель:</h6>
							<p className="card-text text-primary mb-0">VQ35DE</p>
							<h6 className="card-title mb-0">КПП:</h6>
							<p className="card-text text-primary mb-0">АТ</p>
							<h6 className="card-title mb-0">Кузов:</h6>
							<p className="card-text text-primary mb-0">WAGON</p>
							<div className="row justify-content-end">
								<NavLink to="/SearchOverall" className="btn btn-primary mt-3">Поиск запчастей</NavLink>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}



export default SearchResult;
