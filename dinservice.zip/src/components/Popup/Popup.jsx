import React from 'react';
import theme from './../../css/App.module.css';
import style from './css/Popup.module.css';
import $ from "jquery";
import { Link } from 'react-router-dom';
function popup(visibility, window) {
	switch (visibility) {
		case 1:
			$(".popupWrapper").css("display", "flex");
			if (window === "register") {
				$(".popupWindow_register").show();
				$(".popupWindow_login").hide();
				$(".popupWindow_ordering").hide();

			}
			if (window === "login") {
				$(".popupWindow_login").show();
				$(".popupWindow_register").hide();
				$(".popupWindow_ordering").hide();
			}
			if (window === "order") {
				$(".popupWindow_ordering").show();
				$(".popupWindow_register").hide();
				$(".popupWindow_login").hide();
			}
			break;
		case 0:
			$(".popupWrapper").hide();
			if (window === "register") {
				$(".popupWindow_register").hide();
			}
			if (window === "login") {
				$(".popupWindow_login").hide();
			}
			if (window === "order") {
				$(".popupWindow_ordering").hide();
			}
			break;
		default:
			break;
	}
}
class Registration extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			fio: "",
			phone: "",
			city: "",
			address: "",
			email: "",
			password: "",
			is_mailing_subscription: "",
			additional_info: ''
		};

		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}

	async handleSubmit(event) {
		event.preventDefault();
		if (this.state.is_mailing_subscription === true) {
			this.state.is_mailing_subscription = "1";
		}
		else {
			this.state.is_mailing_subscription = "0";
		}
		var data = new FormData();
		data.append("fio", this.state.fio);
		data.append("phone", this.state.phone);
		data.append("password", this.state.password);
		data.append("email", this.state.email);
		data.append("city", this.state.city);
		data.append("address", this.state.address);
		data.append("is_mailing_subscription", this.state.is_mailing_subscription);
		// data.append("additional_info", this.state.additional_info);
		//----------------------------
		let res = await fetch('http://dinas.kz/server/public/api/auth/registration', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		console.log(res);
		if (res.status === "ok") {
			if (res.msg === "Verified mail sended!") {
				alert("Учётная запись успешно создана.");
				popup(0, 'registration');
			}
		}
		else {
			if (res.msg === "Email already!") {
				alert("Данный email адрес уже зарегистрирован. Введите другой адрес.");
			}
			else {
				alert("При регистрации произошла ошибка");
			}
		}
	}

	render() {
		return (
			<form className={` popupWindow_register ${style.popupWindow} ${style.popupWindow_register}`} onSubmit={this.handleSubmit}>
				<div className={` ${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
				<span role="img" aria-label="exit mark" className={` ${style.popupWindow__exit}`} onClick={() => { popup(0, 'register'); }}>&#10060;</span>
				<h2>
					<p onClick={() => { popup(1, 'login'); }}>Вход</p> | <b onClick={() => { popup(1, 'register'); }}>Регистрация</b>
				</h2>
				<div className="row">
					<div className="col-sm-6"><label>
						ФИО:
				<input
							name="fio"
							type="text"
							required
							value={this.state.fio}
							onChange={this.handleInputChange} />
					</label>
						<br />
						<label>
							Номер телефона:
				<input
								name="phone"
								type="tel"
								required
								value={this.state.phone}
								onChange={this.handleInputChange} />
						</label>
						<br />
						<label>
							Город:
				<input
								name="city"
								type="text"
								value={this.state.city}
								onChange={this.handleInputChange} />
						</label>
						<br /></div>
					<div className="col-sm	-6"><label>
						Адрес:
				<input
							name="address"
							type="text"
							required
							value={this.state.address}
							onChange={this.handleInputChange} />
					</label>
						<br />
						<label>
							Email:
				<input
								name="email"
								type="email"
								required
								value={this.state.email}
								onChange={this.handleInputChange} />
						</label>
						<br />
						<label>
							Пароль:
				<input
								name="password"
								type="password"
								required
								value={this.state.password}
								onChange={this.handleInputChange} />
						</label>
						<br /></div>
				</div>
				<div className="col-12 text-center">
					<label>
						Присылать почтовую рассылку:
				<input
							name="is_mailing_subscription"
							type="checkbox"
							checked={this.state.is_mailing_subscription}
							onChange={this.handleInputChange} />
					</label>
				</div>
				<input
					name="additional_info"
					type="text"
					hidden
					value={this.state.additional_info}
					onChange={this.handleInputChange} />
				<div className="col-12">
					<input type="submit" value="Регистрация" className={`${theme.actionBtn}`} />
				</div>
			</form>
		);
	}
}
class Authorization extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			email: "",
			password: ""
		};

		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}

	async handleSubmit(event) {
		event.preventDefault();
		if (this.state.email === "admin" && this.state.password === "7Rtp<+G3Y)E%shcu") {
			localStorage.setItem("dinas_admin", "pneQPLjxCHbJ#X+5XR)3,5CB!Zsy)j+J");
			alert("Вы успешно вошли в админ-панель");
			window.location.href = "/admin";
		}
		else {
			var data = new FormData();
			data.append("password", this.state.password);
			data.append("email", this.state.email);
			//----------------------------
			let res = await fetch('http://dinas.kz/server/public/api/auth/login', {
				method: 'POST',
				body: data
			});
			res = await res.json();
			console.log(res);
			if (res.status === "ok") {
				alert("Вы успешно вошли в аккаунт");
				var user_data = JSON.stringify(res.user);
				localStorage.setItem("user_data", user_data);
				window.location.reload();
			}
			else {
				if (res.msg === "Invalid login or password!") {
					alert("Неверный логин или пароль. Попробуйте ещё раз.");
				}
			}
		}
		//------

	}

	render() {
		return (
			<form className={` popupWindow_login ${style.popupWindow} ${style.popupWindow_login}`} onSubmit={this.handleSubmit}>
				<div className={` ${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
				<span role="img" aria-label="exit mark" className={` ${style.popupWindow__exit}`} onClick={() => { popup(0, 'login'); }}>&#10060;</span>
				<h2>
					<b onClick={() => { popup(1, 'login'); }}>Вход</b> | <p onClick={() => { popup(1, 'register'); }}>Регистрация</p>
				</h2>
				<label>
					Email:
				<input
						name="email"
						type="phone"
						required
						value={this.state.email}
						onChange={this.handleInputChange} />
				</label>
				<label>
					Пароль:
				<input
						name="password"
						type="password"
						required
						value={this.state.password}
						onChange={this.handleInputChange} />
				</label>
				<button className={`${theme.actionBtn}`}>Войти</button> <br></br>
				<Link href="#">Забыли пароль ?</Link>
			</form>
		);
	}
}

class Ordering extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			phone: "",
			name: ""
		};

		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	handleInputChange(event) {
		const target = event.target;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const name = target.name;

		this.setState({
			[name]: value
		});
	}

	async handleSubmit(event) {
		event.preventDefault();
		var data = new FormData();
		data.append("phone", this.state.phone);
		data.append("name", this.state.name);
		//----------------------------
		let res = await fetch('http://dinas.kz/server/public/api/callback/add', {
			method: 'POST',
			body: data
		});
		res = await res.json();
		console.log(res);
		if (res.status === "ok") {
			alert("Ваша заявка успешно отправлена");
			popup(0, "order")
		}
		else {
			alert("При отправке заявки произошла ошибка. Попробуйте ещё раз.");
		}
	}

	render() {
		return (
			<form className={` popupWindow_ordering ${style.popupWindow} ${style.popupWindow_ordering}`} onSubmit={this.handleSubmit}>
				<div className={` ${style.topLeftCorner} ${theme.topLeftCorner}`}></div>
				<span role="img" aria-label="exit mark" className={` ${style.popupWindow__exit}`} onClick={() => { popup(0, 'order'); }}>&#10060;</span>
				<h2>
					<b>Заказать звонок </b>
				</h2>
				<label  >Номер телефона</label> <br></br>
				<input type=" tel" name="phone" onChange={this.handleInputChange} value={this.state.phone}></input> <br></br>
				<label  >Полное имя</label> <br></br>
				<input type="text" name="name" onChange={this.handleInputChange} value={this.state.name}></input>
				<button className={`${theme.actionBtn}`}>Заказать</button> <br></br>
			</form>
		)
	}
}
function Popup() {
	return (
		<div className={`popupWrapper ${style.popupWrapper}`}>
			<Authorization />
			<Registration />
			<Ordering />
		</div>
	);
}

export default Popup;
