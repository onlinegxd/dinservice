import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap-reboot.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { Helmet } from "react-helmet";
import { BrowserRouter, HashRouter, Route, Switch } from "react-router-dom";
import AdminPanel from './components/Admin/Admin';

ReactDOM.render(
	<React.StrictMode>
		<Helmet>
			<meta charSet="utf-8" />
			<title>Dinas Service</title>
			{/* <link rel="canonical" href="http://mysite.com/example" /> */}
		</Helmet>
		<HashRouter>
			<Switch>
				<Route strict path='/admin' component={AdminPanel} />
				<Route path='/' component={App} />
			</Switch>
		</HashRouter>
	</React.StrictMode>,
	document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
